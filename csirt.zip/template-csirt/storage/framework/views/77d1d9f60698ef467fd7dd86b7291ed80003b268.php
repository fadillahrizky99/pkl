

<?php $__env->startSection('container'); ?>
    <!-- Profil Section -->
    <div class="container" style="margin-top:120px">

        <div class="row justify-content mb-5">
            <div>                
                <article class="fs-3">
                    <section id="about-lampung" class="about-lampung pt-10 pb-20 bg-gray-100">
                        <div class="about-lampung-content max-w-6xl mx-auto px-4 sm:px-6 lg:px-8" data-sr-id="2" style="visibility: visible; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transition: opacity 1s cubic-bezier(0.5, 0, 0, 1) 0.2s, transform 1s cubic-bezier(0.5, 0, 0, 1) 0.2s;">
                            <h2 class="text-3xl md:text-4xl font-bold mb-12 text-center">
                                <?php $__currentLoopData = $profils->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h1 class="my-3 text-center">Profil  <?php echo e($profil->name); ?></h1>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </h2>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                                <div class="description">
                                    <p class="text-lg leading-relaxed text-gray-700">
                                    <?php $__currentLoopData = $profils->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $profil->content; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                </div>
                                <div class="image">
                                    <img class="rounded-lg shadow-lg" src="https://images.unsplash.com/photo-1573722740800-cbf53257dde7?q=80&amp;w=1470&amp;auto=format&amp;fit=crop&amp;ixlib=rb-4.0.3&amp;ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Lampung">
                                </div>
                            </div>
                        </div>
                    </section>
                </article>
            </div>
        </div>
    </div> 
    <!-- End Profil Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MasterWebCSIRT_2022\template-csirt\resources\views/profil.blade.php ENDPATH**/ ?>