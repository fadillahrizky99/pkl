

<?php $__env->startSection('container'); ?>

    <div class="container" style="margin-top: 8rem">
        <div class="row justify-content-center mb-5">
            <section id="blog">
                <div class="container">
                    <div class="row mb-3">
                        <h1 class="display-5"><?php echo e($post->title); ?></h1> 
                        <p>
                            Oleh <a href="/posts?author=<?php echo e($post->author->username); ?>" class="text-decoration-none"><?php echo e($post->author->name); ?></a> dalam 
                            <a href="/posts?category=<?php echo e($post->category->slug); ?>" class="text-decoration-none"><?php echo e($post->category->name); ?></a>
                        </p>
                    </div>
                    <div class="card flex"></div>
                </div>
            </section>

            <div class="w-100" style="max-width: 400px; margin: auto;">
                <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="<?php echo e($post->category->name); ?>" class="img-fluid w-100"> 
            </div>

            <article class="my-4 fs-6" style="text-align: justify;">
                <?php echo $post->body; ?>

            </article>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\laragon\www\template-csirt\resources\views/post.blade.php ENDPATH**/ ?>