

<?php $__env->startSection('container'); ?>
    <!-- Service Section -->
    <div class="container" style="margin-top:4rem">
        <div class="row justify-content mb-5">
            <section id="blog">
                <div class="row mb-3">
                    <div class="col-md-10 mx-auto text-center">
                        <h1 class="display-5">Layanan <?php echo e($nama); ?></h1>
                    </div>
                </div>
                <div class="container">
                    <div class="card flex rounded-lg">
                    </div>
                </div> 
            </section>
                            
            <article class="fs-3">
                <section id="about-lampung" class="about-lampung pt-10 pb-20 bg-gray-100">
                    <div class="about-lampung-content max-w-6xl mx-auto px-4 sm:px-6 lg:px-8" data-sr-id="2" style="visibility: visible; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transition: opacity 1s cubic-bezier(0.5, 0, 0, 1) 0.2s, transform 1s cubic-bezier(0.5, 0, 0, 1) 0.2s;">
                        <div class="description" style="text-align: justify;">
                            <p class="text-lg leading-relaxed text-gray-700">
                            <?php $__currentLoopData = $services->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $service->content; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                        </div>
                    </div>
                </section>
            </article>
        </div>
    </div> 
    <!-- End Service Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\laragon\www\template-csirt\resources\views/service.blade.php ENDPATH**/ ?>