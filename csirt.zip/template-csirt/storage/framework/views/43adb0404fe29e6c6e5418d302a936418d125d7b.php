

<?php $__env->startSection('container'); ?>
    <!-- Blog Section -->
    <section id="blog">
        <div class="container">
            <div class="row mb-3">
                <div class="col-md-10 mx-auto text-center">
                    <h1 class="display-5">Posting Terkini</h1> <!-- Use display-1 to display-4 for larger text sizes -->
                </div>
            </div>
        
        <?php if($posts->count()): ?>
            <div class="container">
                <div class="card flex rounded-lg">
                    <?php $__currentLoopData = $posts->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-20 col-md-20 mb-2">
                            <div class="post d-flex">
                                <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="<?php echo e($post->category->name); ?>" class="mr-4" style="width: 300px; height: auto;">
                                <div class="card-body">
                                    <h5 class="card-title"><a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h5>
                                    <p>
                                        <small class="text-muted">
                                            Diposting oleh <a href="/posts?author=<?php echo e($post->author->username); ?>" class="text-decoration-none"><?php echo e($post->author->name); ?></a> di <span class="text-dark"><?php echo e(date('d F Y', strtotime($post->created_at))); ?></span> dalam <span class="text-dark"><?php echo e($post->category->name); ?></span>
                                        </small>
                                    </p>
                                    <p class="card-text"><?php echo e($post->excerpt); ?></p>
                                    <a href="/posts/<?php echo e($post->slug); ?>" class="btn btn-secondary" style="margin-top: 2%; float: right;">Baca Selanjutnya</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        <?php else: ?>
            <p class="text-center fs-4">Tidak ada posting yang ditemukan</p>
        <?php endif; ?>
        
        </div>
    </section>
    <!-- End Blog Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MasterWebCSIRT_2022\template-csirt\resources\views/home.blade.php ENDPATH**/ ?>