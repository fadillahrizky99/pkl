

<?php $__env->startSection('container'); ?>
    <!-- Blog Section -->
    <section id="blog">
        <div class="container">
            <div class="row mb-3">
                <div class="col-md-10 mx-auto text-center">
                    <h1 class="display-5">Posting Terkini</h1> <!-- Use display-1 to display-4 for larger text sizes -->
                </div>
            </div>
        
            <div class="container">
                <div class="card flex rounded-lg">
    
                </div>
            </div>
        </div>
    </section>

    <article class="fs-3">
        <section class="pt-10 bg-gray-100">
            <div class="mx-auto px-4" data-sr-id="2">
                <?php if($posts->count()): ?>
                    <?php $__currentLoopData = $posts->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3">
                            <div class="post d-flex">
                                <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="<?php echo e($post->category->name); ?>" class="mr-4 pic object-contain">
                                <div class="card-body">
                                    <h5 class="card-title"><a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h5>
                                    <p class="text-lg">
                                        <small class="text-muted">
                                            Diposting oleh <a href="/posts?author=<?php echo e($post->author->username); ?>" class="text-decoration-none"><?php echo e($post->author->name); ?></a> di <span class="text-dark"><?php echo e(date('d F Y', strtotime($post->created_at))); ?></span> dalam <span class="text-dark"><?php echo e($post->category->name); ?></span>
                                        </small>
                                    </p>
                                    <p class="text-xl"><?php echo e($post->excerpt); ?></p>
                                    <a href="/posts/<?php echo e($post->slug); ?>" class="btn btn-secondary" style="margin-top: 2%; float: right;">Baca Selanjutnya</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p class="text-center fs-4">Tidak ada posting yang ditemukan</p>
                <?php endif; ?>
            </div>
        </section>
    </article>
    <!-- End Blog Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\app\laragon\www\template-csirt\resources\views/home.blade.php ENDPATH**/ ?>