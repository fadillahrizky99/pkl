<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" aria-current="page" href="/dashboard">
            <span data-feather="home"></span>
            Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard/posts*') ? 'active' : ''); ?>" href="/dashboard/posts">
            <span data-feather="file-text"></span>
            My Post
          </a>
        </li>
      </ul>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
          <span>Administrator</span>
        </h6>
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/categories*') ? 'active' : ''); ?>" href="/dashboard/categories">
              <span data-feather="grid"></span>
              Post Category
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/footers*') ? 'active' : ''); ?>" href="/dashboard/footers">
              <span data-feather="book"></span>
              Post Footer
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/properties*') ? 'active' : ''); ?>" href="/dashboard/properties">
              <span data-feather="image"></span>
              Image Property
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/profils*') ? 'active' : ''); ?>" href="/dashboard/profils">
              <span data-feather="clipboard"></span>
              Profile
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/files*') ? 'active' : ''); ?>" href="/dashboard/files">
              <span data-feather="file"></span>
              File RFC2350
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/services*') ? 'active' : ''); ?>" href="/dashboard/services">
              <span data-feather="award"></span>
              Service
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/keys*') ? 'active' : ''); ?>" href="/dashboard/keys">
              <span data-feather="key"></span>
              PGP Key
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/guidances*') ? 'active' : ''); ?>" href="/dashboard/guidances">
              <span data-feather="book-open"></span>
              File Panduan
            </a>
          </li>
        
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('superadmin')): ?>          
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('dashboard/users*') ? 'active' : ''); ?>" href="/dashboard/users">
              <span data-feather="users"></span>
              User Management
            </a>
          </li>
          <?php endif; ?>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\MasterWebCSIRT_2022\template-csirt\resources\views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>